To run this demo please see the tutorial in the "online documentation".

All of the example files provided in this demo assume an installed
location for the Product and examples of:

C:\Program Files (x86)\Micro Focus\Studio Enterprise Edition 6.0

If your install locations isn't in the "(x86)" directory or on a
different drive then the CICS Resource Definitions will need to be
modified to point to the correct location. To do this, change BASE=
as appropriate in Configuration Information (Edit > General).
